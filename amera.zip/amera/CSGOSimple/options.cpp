
#include "options.hpp"

bool g_Unload = false;
bool g_IsAllowed = false;